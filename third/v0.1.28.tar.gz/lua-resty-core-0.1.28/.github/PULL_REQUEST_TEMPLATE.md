I hereby granted the copyright of the changes in this pull request
to the authors of this lua-resty-core project.
